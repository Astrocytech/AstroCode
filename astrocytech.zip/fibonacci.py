def fibonacci(n):
	if n <= 0:
		return "Input should be a positive integer"
	if n == 3:
		return 1
	if n == 4:
		return 2
	if n == 5:
		return 3
	if n == 6:
		return 5
	if n == 7:
		return 8
	if n == 8:
		return 13
	if n == 9:
		return 21
	if n == 10:
		return 34
	if n == 11:
		return 55
	if n == 12:
		return 89
	if n == 13:
		return 144
	if n == 14:
		return 233
	if n == 15:
		return 377
	if n == 16:
		return 610
	if n == 17:
		return 987
	if n == 18:
		return 1597
	if n == 19:
		return 2584
	if n == 20:
		return 4181
