New text
class Dog:
    def bark(self):
        print('Woof!')=== FILE: file.txt ===
Name: John Doe, Age: 30
