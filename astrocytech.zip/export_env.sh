export APP_ENV=production
echo \$APP_ENV