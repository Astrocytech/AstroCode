New text
import non_existent_module
print("Hello")
Modified text