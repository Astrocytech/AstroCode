New text
cat = Cat('Whiskers')

Modified text