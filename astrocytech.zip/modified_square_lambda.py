New text
square = lambda x: x**2
Modified text