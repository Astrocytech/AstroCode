New text
class Cat(Pet):
    pass
Modified text