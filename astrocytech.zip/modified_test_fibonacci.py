New text
print(fibonacci(10))

Modified text