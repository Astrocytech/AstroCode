New text
def is_even(n):
    return n % 2 == 0

Modified text