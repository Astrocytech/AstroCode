# Usage example:
user = User(name='John Doe', email='john@example.com')
