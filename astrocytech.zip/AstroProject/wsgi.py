# Django's development server doesn't support WSGI, so we need to
# use a production WSGI server like gunicorn.

import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'AstroProject.settings')

application = get_wsgi_application()