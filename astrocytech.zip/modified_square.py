New text
def square(x):
	return x**2
Modified text