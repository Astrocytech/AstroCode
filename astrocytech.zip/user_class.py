@dataclass
class User:
    name: str
    email: str
