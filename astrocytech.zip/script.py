New text

def add(a, b):
  return a + b

def subtract(a, b):
  return a - b

def multiply(a, b):
  return a * b
#!/usr/bin/env python
import os
subprocess.run(['python', '/home/njonji/Desktop/ASTROCYTECH/AstroCode/hardening/script.py'])
