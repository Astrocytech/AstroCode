New text
class Pet:
    pass
Modified text