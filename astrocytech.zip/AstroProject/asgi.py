# Django's development server doesn't support ASGI, so we need to
# use a production ASGI server like daphne.

import os
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'AstroProject.settings')

application = get_asgi_application()