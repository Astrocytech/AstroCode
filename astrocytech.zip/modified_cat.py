New text
class Cat:
    pass
Modified text